export const DB_NAME = "netflix_db";
